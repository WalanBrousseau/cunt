import React from 'react'
import './graphiques-note.css'
import { Bar, Line } from 'react-chartjs-2'

const options = {
	scales: {
		yAxes: [
			{
				ticks: {
					beginAtZero: true,
				},
			},
		],
	},
}

class GraphiqueNote extends React.Component {
	constructor() {
		super()
		this.state = {
			apiData: undefined
		}
	}

    componentDidMount() {
        fetch('http://localhost:8080/sample/api/note').then(response => {
            response.json().then(data => {
                this.setState({apiData: data})
                console.log(data)
            })
        })
    }

	formatApiDataForGridChart = () => {
		let response = {
			labels: [],
			datasets: [
				{
					label: 'Cours',
					data: [],
					backgroundColor: [],
					borderColor: [],
					borderWidth: 1,
				},
			],
		}
		let courses = []
		for (let i = 0; i < this.state.apiData.length; i++) {
			let ponderation = 0
			let note = 0
			for (let j = 0; j < this.state.apiData[i].listNote.length; j++) {
				ponderation += this.state.apiData[i].listNote[j].ponderation
				note += this.state.apiData[i].listNote[j].note
			}
			courses.push({ nom: this.state.apiData[i].nom, note: (note / ponderation) * 100 })
		}
		for (let i = 0; i < courses.length; i++) {
			response.labels.push(courses[i].nom)
			response.datasets[0].data.push(courses[i].note)
			response.datasets[0].backgroundColor.push('rgba(0, 167, 89, 1)')
			response.datasets[0].borderColor.push('rgba(0, 167, 89, 1)')
		}
		return response
	}

	formatApiDataForLineChart = () => {
		let response = {
            labels: [],
            datasets: [
              {
                label: '# Moyenne par cours (%)',
                data: [],
                fill: false,
                backgroundColor: 'rgba(0, 167, 89, 1)',
                borderColor: 'rgba(0, 167, 89, 1)',
              },
              {
                label: 'Moyenne générale (%)',
                data: [1, 2, 1, 1, 2, 2],
                fill: false,
                backgroundColor: 'rgba(0, 0, 0, 0.3)',
                borderColor: 'rgba(0, 0, 0, 0.3)',
              },
            ],
          };
		let courses = []
        let moyenne = []
		for (let i = 0; i < this.state.apiData.length; i++) {
			let ponderation = 0
			let note = 0
			for (let j = 0; j < this.state.apiData[i].listNote.length; j++) {
				ponderation += this.state.apiData[i].listNote[j].ponderation
				note += this.state.apiData[i].listNote[j].note
			}
			courses.push({ nom: this.state.apiData[i].nom, note: (note / ponderation) * 100 })
		}
	}
	render() {
		if (this.state.apiData !== undefined) {
			let barData = this.formatApiDataForGridChart()
			return (
				<>
					<div className="red">
						<Bar data={barData} options={options} />
					</div>
				</>
			)
		}
        return (
        <>
        <h1>Data pas loader</h1>
        </>)
	}
}

export default GraphiqueNote
