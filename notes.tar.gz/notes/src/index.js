import React from 'react';
import ReactDOM from 'react-dom';
import GraphiqueNote from './components/graphiques-note';
import './index.css';

ReactDOM.render(
  <GraphiqueNote />,
  document.getElementById('root')
);